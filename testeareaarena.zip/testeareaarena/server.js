import express from 'express'
import { PrismaClient } from '@prisma/client'
import cors from 'cors'

const prisma = new PrismaClient()

const app = express()

app.use(express.json())
app.use(cors('http://localhost:3000'))

app.post('/itens', async (req, res) => {
    
    await prisma.items.create({
        data:{
            title: req.body.title,
            body: req.body.body,
            created_at: req.body.created_at,
            update_at: req.body.update_at
        }
    })

    res.status(201).json(req.body)
})

app.get('/itens', async (req, res) =>{

    const items = await prisma.items.findMany()
    res.status(200).json(items)
})

app.put('/itens/:id', async (req, res) => {
    
    await prisma.items.update({
        where:{
            id: req.params.id
        },
        data:{
            title: req.body.title
            //body: req.body.body,
            //created_at: req.body.created_at,
            //update_at: req.body.update_at
        }
    })

    res.status(201).json(req.body)
})

app.delete('/itens/:id', async (req, res) => {
    await prisma.items.delete({
        where:{
            id: req.params.id,
        },
    })

    res.status(200).json({message: 'Item deletado com sucesso'})
})

app.listen(3000)