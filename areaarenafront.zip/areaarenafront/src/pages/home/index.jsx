import { useEffect, useState, useRef } from 'react'
import './style.css'
import Excluir from '../../assets/excluir.png'
import api from '../../services/api'

function Home() {

  const [items, setItems] = useState([])

  const inputTitle = useRef()
  const inputBody = useRef()
  const inputCreatedat = useRef()
  const inputUpdateat = useRef()

  async function getItems(){
    const itemsFromApi = await api.get('/items')

    setItems(itemsFromApi.data)
  }

  async function createItems(){
    await api.post('/items', {
      title: inputTitle.current.value,
      body: inputBody.current.value,
      created_at: inputCreatedat.current.value,
      update_at: inputUpdateat.current.value
    })

    getItems()
  }

  async function deleteItems(id){
     await api.delete(`/items/${id}`)

     getItems()

  }

  useEffect(() => {
    getItems()
  }, [])

  return (
    <>
      <div className='container'>

        <form action="">
          <h1>Sua Lista</h1>
          <input type="text" name='title' placeholder="Digite o Title" ref={inputTitle} />
          <input type="text" name='body' placeholder="Digite o Body" ref={inputBody} />
          <input type="text" name='createdat' placeholder="Digite o Created_at" ref={inputCreatedat}/>
          <input type="text" name='updateat' placeholder="Digite o Update_at" ref={inputUpdateat} />
          <button type='button' onClick={createItems}>Cadastrar</button>
        </form>
        {items.map(items => (
          <div key={items.id} className='card'>
            <div>
              <p>Title: <span> {items.title} </span></p>
              <p>Body: <span>{items.body} </span></p>
              <p>Created_at:<span> {items.created_at} </span> </p>
              <p>Update_at:<span> {items.update_at} </span> </p>
            </div>
            <button onClick={ () => deleteItems(items.id)}>
              <img src={Excluir} />
            </button>
          </div>
        ))}

      </div>
    </>
  )
}

export default Home
